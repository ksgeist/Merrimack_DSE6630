# Team Alpha Directory
DSE 6630 Summer 2024

# Team Members:
- Ryan Canfield
- Malek Sabri
- Timothy Shaffer

# Description
This is the directory for team Alpha in the DSE 6630 course during Summer 2024. 
